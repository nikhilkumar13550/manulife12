"""
Manulife Data Letter Generator — Flask Backend
Run: python app.py   →   http://localhost:5055
"""
import json, os, re
from datetime import datetime
from io import BytesIO
from flask import Flask, request, jsonify, send_file, send_from_directory

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_LEFT, TA_JUSTIFY

app = Flask(__name__)

# ── Load policy data ──────────────────────────────────────────────────────────
DATA_FILE = os.path.join(os.path.dirname(__file__), "policies.json")
with open(DATA_FILE) as f:
    POLICIES = json.load(f)

# Build lookup index  {policy_number_str → record}
POLICY_INDEX = {}
for rec in POLICIES:
    pn = rec["policy_number"].strip()
    # Handle multiple policy numbers like "112427, 112461"
    for part in re.split(r'[,\s]+', pn):
        part = part.strip()
        if part:
            POLICY_INDEX.setdefault(part, rec)

# ── Colours ───────────────────────────────────────────────────────────────────
GREEN = colors.HexColor("#00704A")
DARK_GREEN = colors.HexColor("#005A30")
BLACK = colors.black
GREY = colors.HexColor("#555555")

# ── Benefits mapping ──────────────────────────────────────────────────────────
BENEFIT_LABELS = {
    "ELI":  "Employee Life - the amount of coverage (volume)",
    "DLI":  "Dependent Life - 0-None or 1-Family",
    "ADD":  "Employee Basic AD&D - the amount of coverage (volume)",
    "LTD":  "Long Term Disability – the amount of coverage (volume)",
    "STD":  "Short Term Disability – the amount of coverage (volume)",
    "EHC":  "Health Coverage - S-Single, C-Couple, F-Family, W-Waived",
    "DENT": "Dental Coverage - S-Single, C-Couple, F-Family, W-Waived",
    "CIB":  "Critical Illness (Employee Basic) – the amount of coverage (volume)",
    "CIO":  "Critical Illness (Employee Optional) – the amount of coverage (volume)",
    "CIS":  "Critical Illness (Spousal Optional) – the amount of coverage (volume)",
    "CIC":  "Critical Illness (Child Optional) – the amount of coverage (volume)",
}

ALL_BENEFITS = [
    "Employee Life - the amount of coverage (volume)",
    "Dependent Life - 0-None or 1-Family",
    "Employee Basic AD&D - the amount of coverage (volume)",
    "Long Term Disability – the amount of coverage (volume)",
    "Short Term Disability – the amount of coverage (volume)",
    "Health Coverage - S-Single, C-Couple, F-Family, W-Waived",
    "Dental Coverage - S-Single, C-Couple, F-Family, W-Waived",
    "Critical Illness (Employee Basic) – the amount of coverage (volume)",
    "Critical Illness (Employee Optional) – the amount of coverage (volume)",
    "Critical Illness (Spousal Optional) – the amount of coverage (volume)",
    "Critical Illness (Child Optional) – the amount of coverage (volume)",
]

def resolve_benefits(benefits_str, selected_list=None):
    """Return a list of benefit label strings."""
    if selected_list:
        return [b for b in selected_list if b]
    if not benefits_str or benefits_str in ('', 'None', 'nan'):
        return ALL_BENEFITS[:7]
    result = []
    for code in re.split(r'[,\s]+', benefits_str.upper()):
        code = code.strip()
        if code in BENEFIT_LABELS:
            result.append(BENEFIT_LABELS[code])
        elif code:
            result.append(code)
    return result if result else ALL_BENEFITS[:7]


def get_first_name(full_name):
    if not full_name or full_name in ('N/A', 'nan'):
        return "Plan Administrator"
    parts = full_name.strip().split()
    return parts[0] if parts else full_name


def build_pdf_english(data: dict) -> bytes:
    """Generate the English Data Letter PDF."""
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=letter,
        leftMargin=0.85*inch, rightMargin=0.85*inch,
        topMargin=0.5*inch, bottomMargin=0.75*inch
    )

    styles = getSampleStyleSheet()

    # Custom styles
    def style(name, **kw):
        return ParagraphStyle(name, **kw)

    normal = style("N", fontName="Helvetica", fontSize=9.5,
                   leading=14, textColor=BLACK, spaceAfter=0)
    bold_s = style("B", fontName="Helvetica-Bold", fontSize=9.5,
                   leading=14, textColor=BLACK)
    small_grey = style("SG", fontName="Helvetica", fontSize=8.5,
                       leading=12, textColor=GREY)
    header_green = style("HG", fontName="Helvetica-Bold", fontSize=11,
                         textColor=GREEN, leading=15)
    sub_green = style("SBG", fontName="Helvetica-Bold", fontSize=9.5,
                      textColor=GREEN, leading=14)
    body = style("BODY", fontName="Helvetica", fontSize=9.5,
                 leading=14, textColor=BLACK, alignment=TA_JUSTIFY)
    numbered_indent = style("NI", fontName="Helvetica", fontSize=9.5,
                            leading=14, leftIndent=18, textColor=BLACK)

    story = []

    # ── HEADER: Manulife logo only ────────────────────────────────────────────
    date_sent = data.get("date_sent", "").strip()
    header_date = date_sent if date_sent else datetime.today().strftime("%B %d, %Y")
    header_table = Table(
        [[
            Paragraph("<font color='#00704A' size='18'><b>Manulife</b></font>",
                      style("LG", fontName="Helvetica-Bold", fontSize=18,
                            textColor=GREEN, leading=22)),
        ]],
        colWidths=[7*inch]
    )
    header_table.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    story.append(header_table)
    story.append(HRFlowable(width="100%", thickness=2, color=GREEN, spaceAfter=10))

    # ── Date (left-aligned, below green line) ────────────────────────────────
    _BLANK = ('', 'N/A', 'nan', 'None', 'Client Contact Name', 'Client Contact Email')
    contact_name  = data.get("client_contact_name", "")
    company_name  = data.get("policy_name", "")
    contact_email = data.get("client_contact_email", "")
    policy_number = data.get("policy_number", "")
    renewal_year  = data.get("renewal_year", str(datetime.today().year))
    due_date      = data.get("due_date", "")
    ae_name       = data.get("account_executive", "")
    uw_support    = data.get("underwriting_support", "MC Renewal Support")

    story.append(Paragraph(header_date, normal))
    story.append(Spacer(1, 12))

    # ── Contact block ─────────────────────────────────────────────────────────
    if contact_name and contact_name not in _BLANK:
        story.append(Paragraph(contact_name, normal))
    if company_name and company_name not in _BLANK:
        story.append(Paragraph(company_name, normal))
    if contact_email and contact_email not in _BLANK:
        story.append(Paragraph(contact_email, normal))
    story.append(Spacer(1, 12))

    # Dear line — full name
    dear_name = contact_name if contact_name and contact_name not in _BLANK else "Plan Administrator"
    story.append(Paragraph(f"Dear {dear_name},", normal))
    story.append(Spacer(1, 10))

    # Re: line
    story.append(Paragraph(
        f"<b>Re: Renewal Employee Census Data for Policy {policy_number}</b>",
        bold_s
    ))
    story.append(Spacer(1, 10))

    # Body para 1
    story.append(Paragraph(
        f"Manulife is preparing for your {renewal_year} renewal. As part of the renewal process, "
        f"we will require updated employee census data.",
        body
    ))
    story.append(Spacer(1, 8))

    # Body para 2
    due_clause = f" by <b>{due_date}</b>" if due_date else ""
    story.append(Paragraph(
        f"We require the following information, for each employee covered under the policies "
        f"named above. We would appreciate receiving this information{due_clause} to allow "
        f"timely processing of your renewal.",
        body
    ))
    story.append(Spacer(1, 10))

    # Required fields list (always fixed 13 items)
    required_fields = [
        "Unique I.D. for each member",
        "Policy Number",
        "Division",
        "Class",
        "Plan",
        "Name (can be excluded if preferred)",
        "Sex - M or F",
        "Occupation",
        "Province of Residence- AB, BC, MB, NB, NF, NS, NT, ON, PE, PQ, SK, YT",
        "Date of Birth – DD/MMM/YY",
        "Date of Hire – DD/MMM/YY",
        "Accumulated Hours Worked (if used to determine years of service)",
        "Earnings - represents annual salary/earnings on which benefits are based",
    ]
    for i, field in enumerate(required_fields, 1):
        row_table = Table(
            [[Paragraph(f"{i}.", style("NUM", fontName="Helvetica", fontSize=9.5,
                                       leading=13, textColor=BLACK)),
              Paragraph(field, style("FLD", fontName="Helvetica", fontSize=9.5,
                                     leading=13, textColor=BLACK))]],
            colWidths=[0.35*inch, 6.65*inch]
        )
        row_table.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
                                       ("TOPPADDING",(0,0),(-1,-1),1),
                                       ("BOTTOMPADDING",(0,0),(-1,-1),1)]))
        story.append(row_table)

    story.append(Spacer(1, 10))

    # Benefits section
    story.append(Paragraph(
        "Also, for the benefits you currently have with Manulife, we require the following "
        "information for each employee covered:",
        body
    ))
    story.append(Spacer(1, 6))

    benefits = resolve_benefits(
        data.get("benefits", ""),
        data.get("selected_benefits")
    )
    for i, ben in enumerate(benefits, 1):
        row_table = Table(
            [[Paragraph(f"{i}.", style("BN", fontName="Helvetica", fontSize=9.5,
                                       leading=13, textColor=BLACK)),
              Paragraph(ben, style("BF", fontName="Helvetica", fontSize=9.5,
                                   leading=13, textColor=BLACK))]],
            colWidths=[0.35*inch, 6.65*inch]
        )
        row_table.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
                                       ("TOPPADDING",(0,0),(-1,-1),1),
                                       ("BOTTOMPADDING",(0,0),(-1,-1),1)]))
        story.append(row_table)

    story.append(Spacer(1, 10))

    # File formats section
    story.append(Paragraph(
        "Submitting the data electronically allows us to process the information more quickly. "
        "We can process the following file formats:",
        body
    ))
    story.append(Spacer(1, 4))

    formats = [
        "Microsoft Excel (.XLSX) (Saved as an Excel 2010 file)",
        "Comma Delimited ASCII (.TXT or .CDF). String fields are enclosed by quotes and "
        "numeric fields are not. Each field must be separated by a comma. One line represents one record.",
        "Fixed Length ASCII (.TXT or .CDF). Each field has a fixed length for all records. "
        "We require a description of the layout including the field length.",
    ]
    for fmt in formats:
        row_table = Table(
            [[Paragraph("•", style("BUL", fontName="Helvetica", fontSize=9.5,
                                   leading=13, textColor=BLACK)),
              Paragraph(fmt, style("FMT", fontName="Helvetica", fontSize=9.5,
                                   leading=13, textColor=BLACK))]],
            colWidths=[0.2*inch, 6.8*inch]
        )
        row_table.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
                                       ("TOPPADDING",(0,0),(-1,-1),1),
                                       ("BOTTOMPADDING",(0,0),(-1,-1),2)]))
        story.append(row_table)

    story.append(Spacer(1, 10))

    # How to submit
    story.append(Paragraph("<b>How to submit your completed file:</b>", bold_s))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "Submitting your completed file to Manulife electronically is the fastest way to get "
        "your information to us for processing. If providing census data in electronic format is "
        "difficult for you to arrange, we can process paper submissions, however this method "
        "requires manual intervention and does take longer to process. A more secure and quicker "
        "alternative is to log onto the Manulife Group Benefits Secure Site "
        "(www.manulife.ca/Signin) and select the Plan Administrator Link) and upload your "
        "completed file using the Send a File feature selecting the Census File dropdown option.",
        body
    ))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "Manulife does not recommend returning Census Files through email. The security of email "
        "cannot be guaranteed. Email may be lost, intercepted, misused or altered in transit. "
        "When sending Manulife private or confidential information, you are encouraged to do "
        "through our send a file feature, fax or mail.",
        body
    ))
    story.append(Spacer(1, 8))

    # Closing
    due_clause2 = f" by <b>{due_date}</b>" if due_date else ""
    story.append(Paragraph(
        f"We would appreciate receiving this information{due_clause2} to allow timely processing "
        f"of your renewal. If you have any questions, please contact us at the email address "
        f"indicated below.",
        body
    ))
    story.append(Spacer(1, 10))
    story.append(Paragraph("Thank you,", normal))
    story.append(Spacer(1, 18))

    # Signature block
    story.append(Paragraph("MC_Renewal_Support@manulife.ca", style("SIG",
        fontName="Helvetica-Bold", fontSize=9.5, textColor=GREEN, leading=13)))
    story.append(Spacer(1, 4))
    if uw_support and uw_support not in ('MC Renewal Support', 'N/A', ''):
        story.append(Paragraph(uw_support, normal))
    story.append(Paragraph("Underwriting Support", small_grey))
    story.append(Spacer(1, 12))

    # CC block
    story.append(HRFlowable(width="100%", thickness=0.5, color=GREY, spaceAfter=6))
    story.append(Paragraph("cc:", bold_s))
    if ae_name and ae_name not in ('N/A', '', 'nan'):
        story.append(Paragraph(ae_name, normal))
        story.append(Paragraph("Account Executive", small_grey))

    doc.build(story)
    return buf.getvalue()


def build_pdf_french(data: dict) -> bytes:
    """Generate the French Data Letter PDF."""
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=letter,
        leftMargin=0.85*inch, rightMargin=0.85*inch,
        topMargin=0.5*inch, bottomMargin=0.75*inch
    )
    styles = getSampleStyleSheet()

    def style(name, **kw):
        return ParagraphStyle(name, **kw)

    normal = style("N", fontName="Helvetica", fontSize=9.5, leading=14, textColor=BLACK)
    bold_s = style("B", fontName="Helvetica-Bold", fontSize=9.5, leading=14, textColor=BLACK)
    small_grey = style("SG", fontName="Helvetica", fontSize=8.5, leading=12, textColor=GREY)
    body = style("BODY", fontName="Helvetica", fontSize=9.5, leading=14, textColor=BLACK,
                 alignment=TA_JUSTIFY)

    story = []
    _BLANK = ('', 'N/A', 'nan', 'None', 'Client Contact Name', 'Client Contact Email')
    date_sent     = data.get("date_sent", "").strip()
    header_date   = date_sent if date_sent else datetime.today().strftime("%d %B %Y")
    contact_name  = data.get("client_contact_name", "")
    company_name  = data.get("policy_name", "")
    contact_email = data.get("client_contact_email", "")
    policy_number = data.get("policy_number", "")
    renewal_year  = data.get("renewal_year", str(datetime.today().year))
    due_date      = data.get("due_date", "")
    ae_name       = data.get("account_executive", "")
    uw_support    = data.get("underwriting_support", "MC Renewal Support")

    # Header — logo only
    header_table = Table([[
        Paragraph("<font color='#00704A' size='18'><b>Manuvie</b></font>",
                  style("LG", fontName="Helvetica-Bold", fontSize=18,
                        textColor=GREEN, leading=22)),
    ]], colWidths=[7*inch])
    header_table.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                                      ("BOTTOMPADDING",(0,0),(-1,-1),4)]))
    story.append(header_table)
    story.append(HRFlowable(width="100%", thickness=2, color=GREEN, spaceAfter=10))

    # Date left-aligned below the line
    story.append(Paragraph(header_date, normal))
    story.append(Spacer(1, 12))

    if contact_name and contact_name not in _BLANK:
        story.append(Paragraph(contact_name, normal))
    if company_name and company_name not in _BLANK:
        story.append(Paragraph(company_name, normal))
    if contact_email and contact_email not in _BLANK:
        story.append(Paragraph(contact_email, normal))
    story.append(Spacer(1, 12))

    story.append(Paragraph("Madame/Monsieur,", normal))
    story.append(Spacer(1, 10))

    story.append(Paragraph(
        f"<b>Objet : Données du recensement des employés pour le contrat {policy_number}</b>",
        bold_s
    ))
    story.append(Spacer(1, 10))

    story.append(Paragraph(
        f"Manuvie prépare votre renouvellement de {renewal_year}. Dans le cadre du processus "
        f"de renouvellement, nous aurons besoin de données actualisées sur le recensement des employés.",
        body
    ))
    story.append(Spacer(1, 8))

    due_clause = f" avant le <b>{due_date}</b>" if due_date else ""
    story.append(Paragraph(
        f"Nous avons besoin des informations suivantes pour chaque employé couvert par les "
        f"contrats mentionnés ci-dessus. Nous vous saurions gré de nous les fournir{due_clause} "
        f"afin de permettre le traitement de votre renouvellement dans les délais prévus.",
        body
    ))
    story.append(Spacer(1, 10))

    required_fr = [
        "Identifiant unique pour chaque membre",
        "Numéro de contrat",
        "Division",
        "Classe",
        "Plan",
        "Nom (peut être exclu si préféré)",
        "Sexe - M ou F",
        "Profession",
        "Province de résidence- AB, BC, MB, NB, NF, NS, NT, ON, PE, PQ, SK, YT",
        "Date de naissance – JJ/MMM/AA",
        "Date d'embauche – JJ/MMM/AA",
        "Heures accumulées travaillées (si utilisées pour déterminer les années de service)",
        "Salaire - représente le salaire/revenu annuel sur lequel les prestations sont basées",
    ]
    for i, field in enumerate(required_fr, 1):
        row_table = Table(
            [[Paragraph(f"{i}.", style("NUM", fontName="Helvetica", fontSize=9.5,
                                       leading=13, textColor=BLACK)),
              Paragraph(field, style("FLD", fontName="Helvetica", fontSize=9.5,
                                     leading=13, textColor=BLACK))]],
            colWidths=[0.35*inch, 6.65*inch]
        )
        row_table.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
                                       ("TOPPADDING",(0,0),(-1,-1),1),
                                       ("BOTTOMPADDING",(0,0),(-1,-1),1)]))
        story.append(row_table)

    story.append(Spacer(1, 10))

    story.append(Paragraph(
        "De plus, pour les garanties que vous avez actuellement avec Manuvie, nous avons besoin "
        "des informations suivantes pour chaque employé couvert :",
        body
    ))
    story.append(Spacer(1, 6))

    benefits_fr = {
        "Employee Life - the amount of coverage (volume)": "Assurance vie des employés – montant de la couverture (volume)",
        "Dependent Life - 0-None or 1-Family": "Assurance vie des personnes à charge - 0-Aucun ou 1-Famille",
        "Employee Basic AD&D - the amount of coverage (volume)": "Décès et mutilations accidentels de base – montant de la couverture (volume)",
        "Long Term Disability – the amount of coverage (volume)": "Invalidité de longue durée – montant de la couverture (volume)",
        "Short Term Disability – the amount of coverage (volume)": "Invalidité de courte durée – montant de la couverture (volume)",
        "Health Coverage - S-Single, C-Couple, F-Family, W-Waived": "Soins de santé - S-Célibataire, C-Couple, F-Famille, W-Renoncé",
        "Dental Coverage - S-Single, C-Couple, F-Family, W-Waived": "Soins dentaires - S-Célibataire, C-Couple, F-Famille, W-Renoncé",
    }
    benefits = resolve_benefits(data.get("benefits", ""), data.get("selected_benefits"))
    for i, ben in enumerate(benefits, 1):
        ben_fr = benefits_fr.get(ben, ben)
        row_table = Table(
            [[Paragraph(f"{i}.", style("BN", fontName="Helvetica", fontSize=9.5,
                                       leading=13, textColor=BLACK)),
              Paragraph(ben_fr, style("BF", fontName="Helvetica", fontSize=9.5,
                                      leading=13, textColor=BLACK))]],
            colWidths=[0.35*inch, 6.65*inch]
        )
        row_table.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
                                       ("TOPPADDING",(0,0),(-1,-1),1),
                                       ("BOTTOMPADDING",(0,0),(-1,-1),1)]))
        story.append(row_table)

    story.append(Spacer(1, 10))
    story.append(Paragraph(
        "La transmission électronique des données nous permet de traiter les informations plus "
        "rapidement. Nous vous invitons à soumettre vos données via le site sécurisé de "
        "l'Assurance collective de Manuvie (www.manuvie.ca) ou à les envoyer par courriel à "
        "GB.UW.Support@manuvie.ca.",
        body
    ))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Vous remerciant de votre collaboration,", normal))
    story.append(Paragraph("Nous vous prions d'agréer, Madame/Monsieur, nos sincères salutations.", normal))
    story.append(Spacer(1, 18))

    story.append(Paragraph("MC_Renewal_Support@manulife.ca", style("SIG",
        fontName="Helvetica-Bold", fontSize=9.5, textColor=GREEN, leading=13)))
    story.append(Spacer(1, 4))
    if uw_support and uw_support not in ('MC Renewal Support','N/A',''):
        story.append(Paragraph(uw_support, normal))
    story.append(Paragraph("Soutien à la souscription", small_grey))
    story.append(Spacer(1, 12))

    story.append(HRFlowable(width="100%", thickness=0.5, color=GREY, spaceAfter=6))
    story.append(Paragraph("c. c. :", bold_s))
    if ae_name and ae_name not in ('N/A','','nan'):
        story.append(Paragraph(ae_name, normal))
        story.append(Paragraph("Directeur de compte", small_grey))

    doc.build(story)
    return buf.getvalue()


# ── API Routes ────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(os.path.join(os.path.dirname(__file__), "templates"), "index.html")


@app.route("/api/search")
def api_search():
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify({"results": []})
    # Exact match first
    if q in POLICY_INDEX:
        return jsonify({"results": [POLICY_INDEX[q]], "exact": True})
    # Partial match on policy number or name
    q_lower = q.lower()
    results = []
    seen = set()
    for rec in POLICIES:
        pn = rec["policy_number"]
        pname = rec["policy_name"].lower()
        if (q_lower in pn.lower() or q_lower in pname) and pn not in seen:
            results.append(rec)
            seen.add(pn)
        if len(results) >= 10:
            break
    return jsonify({"results": results, "exact": False})


@app.route("/api/generate", methods=["POST"])
def api_generate():
    data = request.json or {}
    lang = data.get("language", "EN").upper()
    try:
        if "FR" in lang or data.get("lang") == "FR":
            pdf_bytes = build_pdf_french(data)
            filename = f"Data_Letter_FR_{data.get('policy_number','')}.pdf"
        else:
            pdf_bytes = build_pdf_english(data)
            filename = f"Data_Letter_EN_{data.get('policy_number','')}.pdf"

        return send_file(
            BytesIO(pdf_bytes),
            mimetype="application/pdf",
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@app.route("/api/benefits")
def api_benefits():
    return jsonify({"benefits": ALL_BENEFITS})


if __name__ == "__main__":
    print("\n🌿 Manulife Data Letter Generator")
    print("   Visit: http://localhost:5055\n")
    app.run(debug=True, port=5055)
