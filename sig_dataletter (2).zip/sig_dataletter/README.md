# Manulife Data Letter Generator — POC

## What it does
- Search **3,583 policies** from the BPS Underwriting Tracker by policy number or company name
- Auto-fills all letter fields (client name, email, AE, due date, renewal year, benefits)
- Edit any field before generating
- Select/deselect benefits to include in the letter
- Generate **English or French** PDF with full Manulife letter format
- Manual entry mode if policy is not in the tracker

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Open: **http://localhost:5055**

## How to use

1. Type a policy number (e.g. `112503`) or company name in the search box
2. Click the matching result — all fields auto-populate from the tracker
3. Review and edit any fields if needed
4. Select which benefits to include
5. Click **Create English Data Letter** or **Créer la lettre en français**
6. PDF downloads automatically

## Files

```
data-letter-poc/
├── app.py              → Flask API + PDF generation (ReportLab)
├── policies.json       → 3,583 policies extracted from BPS tracker
├── requirements.txt
└── templates/
    └── index.html      → React frontend (Manulife UI)
```

## Data Source
Extracted from: `BPS_Underwriting_Tracker_-_Signature_Data_Letter.xlsm`
Sheets: "Sig Data Letters Completed" + "Sig Data Letters in Progress"

## Notes for Production
- Replace `policies.json` with live database/API connection
- Add user authentication (Azure AD / SPN)
- Add audit logging (who generated which letter, when)
- Consider adding email-sending capability via Azure Communication Services
